cp::[[a]]->[[a]]


cp [xs, ys] = [[x]++[y] | x<-xs, y<-ys]