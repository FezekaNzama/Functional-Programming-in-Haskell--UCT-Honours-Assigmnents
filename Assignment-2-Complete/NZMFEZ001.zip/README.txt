
TM state configurations for Input “aba”

<q0, a, blank, q1>
<q1, b, b, q1>
<q1, a, a, q1>
<q1, blank, blank, q2>
<q2, a, blank, q3>
<q3, b, b, q3>
<q3, blank, blank, q0>
<q0, b, blank, q4>
<q4, blank, blank, q5>
<q5, blank, blank, qAccept>
